package com.project.emp.SymboisisProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SymboisisProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SymboisisProjectApplication.class, args);
	}

}
