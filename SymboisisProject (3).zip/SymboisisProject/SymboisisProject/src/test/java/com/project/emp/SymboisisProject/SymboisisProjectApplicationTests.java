package com.project.emp.SymboisisProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SymboisisProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
